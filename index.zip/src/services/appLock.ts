import * as LocalAuthentication from 'expo-local-authentication';
import { settingsRepository } from '../database/repositories/settingsRepository';
import { Platform } from 'react-native';

export interface LockState {
  isLocked: boolean;
  requiresAuth: boolean;
}

class AppLockService {
  private lockState: LockState = { isLocked: false, requiresAuth: false };
  private listeners: ((state: LockState) => void)[] = [];
  private autoLockTimer: ReturnType<typeof setTimeout> | null = null;
  private lastActiveTime: number = Date.now();

  constructor() {
    this.init();
  }

  private async init() {
    const settings = await settingsRepository.getSettings();
    this.lockState = {
      isLocked: settings.pinEnabled || settings.biometricEnabled,
      requiresAuth: settings.pinEnabled || settings.biometricEnabled,
    };
    this.startAutoLockTimer(settings.autoLockMinutes);
  }

  subscribe(listener: (state: LockState) => void) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach(l => l(this.lockState));
  }

  private startAutoLockTimer(minutes: number) {
    if (this.autoLockTimer) {
      clearTimeout(this.autoLockTimer);
    }
    if (minutes > 0) {
      this.autoLockTimer = setTimeout(() => {
        this.lock();
      }, minutes * 60 * 1000);
    }
  }

  async recordActivity() {
    this.lastActiveTime = Date.now();
    const settings = await settingsRepository.getSettings();
    this.startAutoLockTimer(settings.autoLockMinutes);
  }

  async lock() {
    const settings = await settingsRepository.getSettings();
    if (settings.pinEnabled || settings.biometricEnabled) {
      this.lockState = { isLocked: true, requiresAuth: true };
      this.notify();
    }
  }

  async unlock(authMethod: 'pin' | 'biometric' = 'pin') {
    const settings = await settingsRepository.getSettings();
    
    if (authMethod === 'biometric' && settings.biometricEnabled) {
      const result = await LocalAuthentication.authenticateAsync({
        promptMessage: 'Unlock Calmly',
        fallbackLabel: 'Use PIN',
        cancelLabel: 'Cancel',
      });
      if (result.success) {
        this.lockState = { isLocked: false, requiresAuth: false };
        this.notify();
        return true;
      }
    }

    return false;
  }

  async verifyPin(pin: string): Promise<boolean> {
    return settingsRepository.verifyPin(pin);
  }

  getState(): LockState {
    return this.lockState;
  }

  isLocked(): boolean {
    return this.lockState.isLocked;
  }

  cleanup() {
    if (this.autoLockTimer) {
      clearTimeout(this.autoLockTimer);
    }
  }
}

export const appLockService = new AppLockService();

export function useAppLock() {
  const [state, setState] = useState<LockState>(appLockService.getState());
  
  useEffect(() => {
    const unsubscribe = appLockService.subscribe(setState);
    return unsubscribe;
  }, []);

  return {
    ...state,
    lock: () => appLockService.lock(),
    unlock: (method?: 'pin' | 'biometric') => appLockService.unlock(method),
    verifyPin: (pin: string) => appLockService.verifyPin(pin),
    recordActivity: () => appLockService.recordActivity(),
  };
}

import { useState, useEffect } from 'react';