import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import { settingsRepository } from '../database/repositories/settingsRepository';
import { getEncouragement } from '../utils/encouragement';

export type NotificationCategory = 
  | 'morningCheckIn'
  | 'journalReminder'
  | 'habitReminder'
  | 'eveningReflection'
  | 'sleepRoutine'
  | 'weeklyReflection';

export interface ScheduledNotification {
  id: string;
  category: NotificationCategory;
  title: string;
  body: string;
  trigger: Notifications.NotificationTriggerInput;
}

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: false,
    shouldSetBadge: false,
  }),
});

export const notificationService = {
  async requestPermissions(): Promise<boolean> {
    if (Platform.OS === 'web') return false;
    
    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;
    
    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync({
        ios: {
          allowAlert: true,
          allowBadge: false,
          allowSound: false,
          allowAnnouncements: false,
        },
      });
      finalStatus = status;
    }
    
    return finalStatus === 'granted';
  },

  async scheduleAll(): Promise<void> {
    const hasPermission = await this.requestPermissions();
    if (!hasPermission) return;

    await this.cancelAll();

    const config = await settingsRepository.getNotificationConfig();
    if (!config.enabled) return;

    const notifications = this.generateNotifications(config);
    
    for (const notif of notifications) {
      await Notifications.scheduleNotificationAsync({
        content: {
          title: notif.title,
          body: notif.body,
          data: { category: notif.category },
        },
        trigger: notif.trigger,
      });
    }
  },

  generateNotifications(config: any): ScheduledNotification[] {
    const now = new Date();
    const notifications: ScheduledNotification[] = [];

    const categories: { key: NotificationCategory; label: string; cat: string }[] = [
      { key: 'morningCheckIn', label: 'Morning Check-In', cat: 'morning' },
      { key: 'journalReminder', label: 'Journal Reminder', cat: 'journal' },
      { key: 'habitReminder', label: 'Habit Reminder', cat: 'habit' },
      { key: 'eveningReflection', label: 'Evening Reflection', cat: 'journal' },
      { key: 'sleepRoutine', label: 'Sleep Routine', cat: 'calm' },
      { key: 'weeklyReflection', label: 'Weekly Reflection', cat: 'general' },
    ];

    categories.forEach(({ key, label, cat }) => {
      if (!config.categories[key]) return;
      if (!config.times[key]) return;

      const [hours, minutes] = config.times[key].split(':').map(Number);
      
      notifications.push({
        id: `${key}-daily`,
        category: key,
        title: `Time for ${label} 🌿`,
        body: getEncouragement(cat as any),
        trigger: {
          type: Notifications.SchedulableTriggerInputTypes.DAILY,
          hour: hours,
          minute: minutes,
          repeats: true,
        } as Notifications.DailyTriggerInput,
      });
    });

    return notifications;
  },

  async cancelAll(): Promise<void> {
    await Notifications.cancelAllScheduledNotificationsAsync();
  },

  async cancelCategory(category: NotificationCategory): Promise<void> {
    const scheduled = await Notifications.getAllScheduledNotificationsAsync();
    const toCancel = scheduled
      .filter(n => n.content.data?.category === category)
      .map(n => n.identifier);
    await Promise.all(toCancel.map(id => Notifications.cancelScheduledNotificationAsync(id)));
  },

  async scheduleTestNotification(category: NotificationCategory): Promise<void> {
    const config = await settingsRepository.getNotificationConfig();
    if (!config.enabled) return;

    const notifications = this.generateNotifications(config);
    const target = notifications.find(n => n.category === category);
    
    if (target) {
      await Notifications.scheduleNotificationAsync({
        content: {
          title: target.title,
          body: target.body,
          data: { category: target.category, test: true },
        },
        trigger: { seconds: 5, repeats: false },
      });
    }
  },

  async getScheduledCount(): Promise<number> {
    const scheduled = await Notifications.getAllScheduledNotificationsAsync();
    return scheduled.length;
  },
};

export function useNotifications() {
  const [permission, setPermission] = useState<'granted' | 'denied' | 'undetermined'>('undetermined');
  const [scheduledCount, setScheduledCount] = useState(0);

  useEffect(() => {
    checkPermission();
    loadScheduledCount();
  }, []);

  const checkPermission = async () => {
    const { status } = await Notifications.getPermissionsAsync();
    setPermission(status);
  };

  const loadScheduledCount = async () => {
    const count = await notificationService.getScheduledCount();
    setScheduledCount(count);
  };

  const requestPermission = async () => {
    const granted = await notificationService.requestPermissions();
    await checkPermission();
    if (granted) {
      await notificationService.scheduleAll();
      await loadScheduledCount();
    }
    return granted;
  };

  const rescheduleAll = async () => {
    await notificationService.scheduleAll();
    await loadScheduledCount();
  };

  const toggleCategory = async (category: NotificationCategory, enabled: boolean) => {
    await settingsRepository.updateNotificationConfig({
      [category === 'morningCheckIn' ? 'morningCheckInCat' :
       category === 'journalReminder' ? 'journalReminderCat' :
       category === 'habitReminder' ? 'habitReminderCat' :
       category === 'eveningReflection' ? 'eveningReflectionCat' :
       category === 'sleepRoutine' ? 'sleepRoutineCat' :
       'weeklyReflectionCat']: enabled,
    });
    if (enabled) {
      await notificationService.scheduleAll();
    } else {
      await notificationService.cancelCategory(category);
    }
    await loadScheduledCount();
  };

  return {
    permission,
    scheduledCount,
    requestPermission,
    rescheduleAll,
    toggleCategory,
    scheduleTest: notificationService.scheduleTestNotification,
  };
}

import { useState, useEffect } from 'react';