import { createMMKV } from 'react-native-mmkv';

const storage = createMMKV();

export const Storage = {
  getString: (key: string): string | undefined => {
    return storage.getString(key);
  },
  setString: (key: string, value: string): void => {
    storage.set(key, value);
  },
  getBoolean: (key: string): boolean | undefined => {
    const value = storage.getString(key);
    return value ? JSON.parse(value) : undefined;
  },
  setBoolean: (key: string, value: boolean): void => {
    storage.set(key, JSON.stringify(value));
  },
  getNumber: (key: string): number | undefined => {
    const value = storage.getString(key);
    return value ? JSON.parse(value) : undefined;
  },
  setNumber: (key: string, value: number): void => {
    storage.set(key, JSON.stringify(value));
  },
  getObject: <T>(key: string): T | undefined => {
    const value = storage.getString(key);
    return value ? JSON.parse(value) : undefined;
  },
  setObject: <T>(key: string, value: T): void => {
    storage.set(key, JSON.stringify(value));
  },
  delete: (key: string): void => {
    storage.remove(key);
  },
  clearAll: (): void => {
    storage.clearAll();
  },
  getAllKeys: (): string[] => {
    return storage.getAllKeys();
  },
};