import { database } from '..';
import { Q } from '@nozbe/watermelondb';
import { UserSetting } from '../models/UserSetting';

const settingsCollection = database.get<UserSetting>('user_settings');

export interface AppSettings {
  biometricEnabled: boolean;
  pinEnabled: boolean;
  pinHash?: string;
  autoLockMinutes: number;
  hideContentInSwitcher: boolean;
  theme: 'light' | 'dark' | 'system';
  accent: 'sage' | 'lavender' | 'sky' | 'peach' | 'rose' | 'ocean';
  reducedMotion: boolean;
  hapticsEnabled: boolean;
  notificationsEnabled: boolean;
  notificationTimes: {
    morningCheckIn: string;
    journalReminder: string;
    habitReminder: string;
    eveningReflection: string;
    sleepRoutine: string;
    weeklyReflection: string;
  };
  notificationCategories: {
    morningCheckIn: boolean;
    journalReminder: boolean;
    habitReminder: boolean;
    eveningReflection: boolean;
    sleepRoutine: boolean;
    weeklyReflection: boolean;
  };
}

const DEFAULT_SETTINGS: AppSettings = {
  biometricEnabled: false,
  pinEnabled: false,
  autoLockMinutes: 5,
  hideContentInSwitcher: true,
  theme: 'system',
  accent: 'sage',
  reducedMotion: false,
  hapticsEnabled: true,
  notificationsEnabled: true,
  notificationTimes: {
    morningCheckIn: '08:00',
    journalReminder: '20:00',
    habitReminder: '09:00',
    eveningReflection: '21:00',
    sleepRoutine: '22:00',
    weeklyReflection: '10:00',
  },
  notificationCategories: {
    morningCheckIn: true,
    journalReminder: true,
    habitReminder: true,
    eveningReflection: true,
    sleepRoutine: true,
    weeklyReflection: true,
  },
};

export const settingsRepository = {
  async getSettings(): Promise<AppSettings> {
    try {
      const setting = await settingsCollection
        .query(Q.where('key', 'app_settings'), Q.take(1))
        .fetch();
      if (setting.length > 0) {
        return { ...DEFAULT_SETTINGS, ...JSON.parse(setting[0].value) };
      }
      return DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  },

  async updateSettings(data: Partial<AppSettings>) {
    return database.write(async () => {
      const current = await this.getSettings();
      const updated = { ...current, ...data };
      const existing = await settingsCollection
        .query(Q.where('key', 'app_settings'), Q.take(1))
        .fetch();
      if (existing.length > 0) {
        await existing[0].update((s) => {
          s.value = JSON.stringify(updated);
          s.updatedAt = Date.now();
        });
      } else {
        await settingsCollection.create((s) => {
          s.key = 'app_settings';
          s.value = JSON.stringify(updated);
          s.createdAt = Date.now();
          s.updatedAt = Date.now();
        });
      }
    });
  },

  async setPin(pin: string) {
    const hash = await this.hashPin(pin);
    await this.updateSettings({ pinEnabled: true, pinHash: hash });
  },

  async verifyPin(pin: string): Promise<boolean> {
    const settings = await this.getSettings();
    if (!settings.pinHash) return false;
    const hash = await this.hashPin(pin);
    return hash === settings.pinHash;
  },

  async removePin() {
    await this.updateSettings({ pinEnabled: false, pinHash: undefined });
  },

  async hashPin(pin: string): Promise<string> {
    const encoder = new TextEncoder();
    const data = encoder.encode(pin + 'calmly_salt_2024');
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  },

  async getNotificationConfig() {
    const settings = await this.getSettings();
    return {
      enabled: settings.notificationsEnabled,
      times: settings.notificationTimes,
      categories: settings.notificationCategories,
    };
  },

  async updateNotificationConfig(config: Partial<AppSettings['notificationTimes'] & AppSettings['notificationCategories'] & { enabled?: boolean }>) {
    const settings = await this.getSettings();
    const updated: AppSettings = { ...settings };
    if (config.enabled !== undefined) updated.notificationsEnabled = config.enabled;
    if (config.morningCheckIn !== undefined) updated.notificationTimes.morningCheckIn = config.morningCheckIn;
    if (config.journalReminder !== undefined) updated.notificationTimes.journalReminder = config.journalReminder;
    if (config.habitReminder !== undefined) updated.notificationTimes.habitReminder = config.habitReminder;
    if (config.eveningReflection !== undefined) updated.notificationTimes.eveningReflection = config.eveningReflection;
    if (config.sleepRoutine !== undefined) updated.notificationTimes.sleepRoutine = config.sleepRoutine;
    if (config.weeklyReflection !== undefined) updated.notificationTimes.weeklyReflection = config.weeklyReflection;
    if (config.morningCheckInCat !== undefined) updated.notificationCategories.morningCheckIn = config.morningCheckInCat;
    if (config.journalReminderCat !== undefined) updated.notificationCategories.journalReminder = config.journalReminderCat;
    if (config.habitReminderCat !== undefined) updated.notificationCategories.habitReminder = config.habitReminderCat;
    if (config.eveningReflectionCat !== undefined) updated.notificationCategories.eveningReflection = config.eveningReflectionCat;
    if (config.sleepRoutineCat !== undefined) updated.notificationCategories.sleepRoutine = config.sleepRoutineCat;
    if (config.weeklyReflectionCat !== undefined) updated.notificationCategories.weeklyReflection = config.weeklyReflectionCat;
    return this.updateSettings(updated);
  },
};