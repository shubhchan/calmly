import { Database as WatermelonDatabase } from '@nozbe/watermelondb';
import SQLiteAdapter from '@nozbe/watermelondb/adapters/sqlite';
import { schema } from './schema';
import {
  UserSetting,
  MoodEntry,
  JournalEntry,
  Habit,
  HabitCompletion,
  GratitudeEntry,
  CalmSession,
  BreathingSession,
  MeditationSession,
  SleepEntry,
  Reflection,
  Affirmation,
  Favorite,
  Tag,
  Routine,
  RoutineItem,
  Goal,
} from './models';

const adapter = new SQLiteAdapter({
  schema,
});

export const database = new WatermelonDatabase({
  adapter,
  modelClasses: [
    UserSetting,
    MoodEntry,
    JournalEntry,
    Habit,
    HabitCompletion,
    GratitudeEntry,
    CalmSession,
    BreathingSession,
    MeditationSession,
    SleepEntry,
    Reflection,
    Affirmation,
    Favorite,
    Tag,
    Routine,
    RoutineItem,
    Goal,
  ],
});

export type AppDatabase = typeof database;