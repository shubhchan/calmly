import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { TabParamList } from '../types/navigation';
import { HomeStack } from '../features/home/HomeStack';
import { JournalStack } from '../features/journal/JournalStack';
import { CalmStack } from '../features/calm/CalmStack';
import { InsightsStack } from '../features/insights/InsightsStack';
import { SettingsStack } from '../features/settings/SettingsStack';
import { HabitStack } from '../features/habits/HabitStack';
import { GratitudeStack } from '../features/gratitude/GratitudeStack';
import { AffirmationsStack } from '../features/gratitude/AffirmationsStack';
import { SelfCompassionStack } from '../features/gratitude/SelfCompassionStack';
import { WhatCanIControlStack } from '../features/gratitude/WhatCanIControlStack';
import { ThoughtReframingStack } from '../features/gratitude/ThoughtReframingStack';

const Tab = createBottomTabNavigator<TabParamList>();

export function AppNavigator() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: '#5A955A',
        tabBarInactiveTintColor: '#425474',
        tabBarStyle: {
          backgroundColor: 'transparent',
          elevation: 0,
          shadowOpacity: 0,
        },
      })}
    >
      <Tab.Screen
        name="Home"
        component={HomeStack}
        options={{ tabBarButton: () => null }}
      />
      <Tab.Screen
        name="Journal"
        component={JournalStack}
        options={{ tabBarButton: () => null }}
      />
      <Tab.Screen
        name="Calm"
        component={CalmStack}
        options={{ tabBarButton: () => null }}
      />
      <Tab.Screen
        name="Insights"
        component={InsightsStack}
        options={{ tabBarButton: () => null }}
      />
      <Tab.Screen
        name="Settings"
        component={SettingsStack}
        options={{ tabBarButton: () => null }}
      />
    </Tab.Navigator>
  );
}

export function RootNavigator() {
  const Stack = createNativeStackNavigator<{
    App: undefined;
    Onboarding: undefined;
    AppLock: undefined;
    Habits: undefined;
    HabitDetail: { id: string };
    HabitForm: { id?: string };
    Routines: undefined;
    RoutineDetail: { timeOfDay: 'morning' | 'afternoon' | 'evening'; routine?: any };
    Gratitude: { type: 'gratitude' | 'positive' };
    GratitudeForm: { type: 'gratitude' | 'positive'; id?: string };
    Affirmations: undefined;
    AffirmationDetail: { id: string };
    SelfCompassion: undefined;
    WhatCanIControl: undefined;
    ThoughtReframing: undefined;
    Notifications: undefined;
    AppLockSettings: undefined;
    SetPin: { onComplete?: () => void };
    DataManagement: undefined;
  }>();

  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="App" component={AppNavigator} />
      <Stack.Screen name="Onboarding" component={OnboardingScreen} />
      <Stack.Screen name="AppLock" component={AppLockScreen} />
      <Stack.Screen name="Habits" component={HabitStack} />
      <Stack.Screen name="HabitDetail" component={HabitStack} />
      <Stack.Screen name="HabitForm" component={HabitStack} />
      <Stack.Screen name="Routines" component={HabitStack} />
      <Stack.Screen name="RoutineDetail" component={HabitStack} />
      <Stack.Screen name="Gratitude" component={GratitudeStack} />
      <Stack.Screen name="GratitudeForm" component={GratitudeStack} />
      <Stack.Screen name="Affirmations" component={AffirmationsStack} />
      <Stack.Screen name="AffirmationDetail" component={AffirmationsStack} />
      <Stack.Screen name="SelfCompassion" component={SelfCompassionStack} />
      <Stack.Screen name="WhatCanIControl" component={WhatCanIControlStack} />
      <Stack.Screen name="ThoughtReframing" component={ThoughtReframingStack} />
      <Stack.Screen name="Notifications" component={SettingsStack} />
      <Stack.Screen name="AppLockSettings" component={SettingsStack} />
      <Stack.Screen name="SetPin" component={SettingsStack} />
      <Stack.Screen name="DataManagement" component={SettingsStack} />
    </Stack.Navigator>
  );
}

function OnboardingScreen() {
  return null;
}

function AppLockScreen() {
  return null;
}