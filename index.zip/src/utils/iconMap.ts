export function getIconName(icon: string): string {
  const iconMap: Record<string, string> = {
    water: 'water',
    fitness: 'fitness',
    book: 'book',
    meditation: 'meditation',
    sunny: 'sunny',
    moon: 'moon',
    leaf: 'leaf',
    heart: 'heart',
    'musical-notes': 'musical-notes',
    camera: 'camera',
    bicycle: 'bicycle',
    walk: 'walk',
    sleep: 'bed',
    nutrition: 'nutrition',
    code: 'code',
    brush: 'brush',
    pill: 'pill',
    flash: 'flash',
    diamond: 'diamond',
    star: 'star',
    flower: 'flower',
    tree: 'tree',
    cloud: 'cloud',
    flame: 'flame',
  };
  return iconMap[icon] || 'checkbox-outline';
}